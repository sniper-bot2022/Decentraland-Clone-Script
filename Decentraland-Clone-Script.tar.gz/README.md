# Nethereum-Token-Sniper

This Token Sniper is a potentially very profitable trading bot (assuming that the right tokens are sniped and that there is minimal slippage). What it essentially does is look for new liquidity pairs being created, which are pairs of cryptocurrencies which are being compared to each other in price and then swap one token for the other. This has a large potential for profit as these pairs may be created as a new cryptocurrency is being launched on the blockchain, and as a result, the user gets early access to a token which they believe will significantly grow in price. 

This project is not finished and further development is not planned. This project simply acts as an example of a Nethereum and C# project which I have been very close to completing.
